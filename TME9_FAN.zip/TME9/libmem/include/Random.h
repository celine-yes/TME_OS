#ifndef _RANDOMSWAPPER_H_
#define _RANDOMSWAPPER_H_

#include "Swapper.h"

int initRandomSwapper(Swapper*,unsigned int); //nb of virtual pages, nb of physical pages

#endif
